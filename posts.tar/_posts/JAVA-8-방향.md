---
title: JAVA 8 방향
date: 2016-10-30 08:39:59
categories: Think
tags: 잡동사니
---

### 자바가 앞으로 지향해야 할 방향이라 생각되는 항목들.
- ReactiveX
- 옵저버패턴
- 스케쥴링
- 모나드
- micro service architecture
