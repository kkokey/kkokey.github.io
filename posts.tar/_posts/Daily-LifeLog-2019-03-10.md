---
title: '[Daily LifeLog] 2019/03/10'
date: 2019-03-11 00:54:23
categories: 라이프로그
tags: LifeLog
---

2019년 3월 10일자 라이프로그 입니다.

- 운동

  주말 운동은 쉽니다!

- 영어 공부

  오늘의 단어입니다.

  accusing (형용사, ADJECTIVE)
	-> (of an expression, gesture, or tone of voice) indicating a belief in someone`s guilt or culpability.
	: 누군가의 죄나 과실(표현의, 행동, 목소리의 어조)에 대해 확고한 믿음을 보이는 것

  hoaxes (명사, NOUN)
	-> A humorous or malicious deception.
	: 유머러스 또는 악의적인 속임수.

	예문입니다.

	-> The president has been at war with news outlets, accusing any negative comment about him and his campaign of being "fake news".
	: 대통령은 그에 관한 부정적 논평과 가짜 뉴스에 대해 비난하며, 뉴스 매체와 전쟁 중이다.

	-> Fake news is deliberately published hoaxes
	: 가짜 뉴스는 고의적인 거짓 뉴스입니다. 

	이상입니다.

- 독서 로그

	오늘도 읽은 책은 없습니다.
	충분히 쉬었으니 내일 부터는 또 달려볼께요!

2019년에는 모두 같이 성장합시다!
