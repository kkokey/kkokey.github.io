---
title: Linux 유용한 명령어
date: 2016-10-30 21:08:42
categories: Linux
tags: 
- 명령어
- 개발환경
---

Linux 유용한 명령어.

``` bash
$ vi {filename}
```
 - 리눅스 기본적인 편집기.
 - 사용하다 보면 너무 편해서 다른 거 못쓴다.

``` bash
$ cd -
```
 - linux shell 작업 중 이전 디렉토리로 이동 시킨다.
