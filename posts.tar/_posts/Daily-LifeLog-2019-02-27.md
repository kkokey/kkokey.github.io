---
title: '[Daily LifeLog] 2019/02/27'
date: 2019-02-27 23:09:05
categories: 라이프로그
tags: LifeLog
---

2019년 2월 27일자 라이프로그 입니다.

- 운동
  성공!
  → 오늘도 20층 계단 오르기 완료!

- 영어 공부
  오늘은 3개의 단어를 가져와봤어요.
  아래는 각 단어의 사전적인 의미에요.    

  mundane (형용사)
	 → Lacking interest or excitement;
	 : 흥미나 흥분이 부족한 상태에 대해 얘기합니다.

	pinpoint (형용사)
   → Find or identify with great accuracy or precision. (with object)
	 : 정확하게 찝어내거나 찾아내는 것을 뜻합니다.

	half-ass (동사)
	 → Do (something) with little effort or care.
	 : 적은 힘을 들여 또는 적은 노력으로 무엇인가를 하는것에 얘기합니다.

	예문입니다.

	When I was college student, I had felt mundane and boring to from my life routine.
	내가 대학생이었을 때 나는 내 삶이 평범하고 지루하다고 느꼈다.

	At finally, I found pinpoint why I could not solve that problem.
	마침내 나는 왜 그 문제를 햐결하지 못했는지 정확하게 찾았습니다.

	Please, At this time never half-ass. You should concentrate that solve the problem.
	제발 이번에는 건성으로 하지마. 너는 이 문제를 푸는데 집중해야 해.

	오늘은 여기까지입니다!
	오늘은 단어를 찾고 관련된 문장을 만들어봤어요. 시간은 조금 더 걸리는데 할만하네요!
	더 도움이 되기도 하는거 같구요!
	앞으로도 이렇게 해볼 생각입니다.

	- 독서 로그
	프로그래머를 위한 기초 해석학을 읽는 중입니다.

2019년에는 모두 같이 성장합시다!
