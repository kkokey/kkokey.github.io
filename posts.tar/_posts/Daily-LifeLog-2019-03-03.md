---
title: '[Daily LifeLog] 2019/03/03'
date: 2019-03-03 23:23:35
categories: 라이프로그
tags: LifeLog
---

2019년 3월 3일자 라이프로그 입니다.

- 운동

주말 운동은 쉽니다!

- 영어 공부

  오늘의 단어입니다.
  
  improve(동사, verb)
	-> Make or become better.
	: 더 좋게 하다 또는 만들다.

	suggest(동사, verb)
	-> Put forward for consideration.
	: 고려할 것을 내놓다.

	예문입니다.
	-> I subscribed to two magazines to improve my mind
	: 나는 나의 지성을 향상시키기 위해 두개의 잡지를 구동했다.

	-> I always suggest learning how to study.
	: 나는 항상 공부하는 법을 배우라고 제안합니다.

	이상입니다.
	이전에 썼던 글들을 보니 형태가 제각각이네요.
	앞으로는 좀 일정한 형태를 유지하려고 합니다.
	그래야 보는 분도 편할테니 말이죠! :)

- 독서 로그
	프로그래머를 위한 기초 해석학을 읽는 중입니다.
	지금은 함수의 기본 특성 부분을 읽고 있지만,
	서평을 위해 빠르게 읽은 후 서평을 먼저 작성하고 나서 계속 읽어야 겠습니다. :)

2019년에는 모두 같이 성장합시다!
