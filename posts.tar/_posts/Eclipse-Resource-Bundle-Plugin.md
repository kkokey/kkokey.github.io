---
title: Eclipse Resource Bundle Plugin
date: 2016-10-31 20:25:31
categories: Eclipse Plugin
tags: 개발환경
---

- Plugin 이름 : Eclipse ResourceBundle Plugin (Properties Plugin)

- 홈페이지 : http://eclipse-rbe.sourceforge.net/index.htm

- 설치 방법 : Eclipse의 plugin 폴더 내에 복사.

이클립스 개발 환경에서 properties Resource 다국어 처리시에 사용.
