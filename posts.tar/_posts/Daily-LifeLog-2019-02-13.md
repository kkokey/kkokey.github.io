---
title: '[Daily LifeLog] 2019/02/13'
date: 2019-02-13 23:49:00
categories: 라이프로그
tags: LifeLog
---

2019년 2월 13일자 라이프로그 입니다.

- 운동
	계획했던 20층 계단 오르기를 오늘도 수행 했습니다.
	오늘은 점심 먹고 얘기하는 자리가 길어져서 급하게 걸억느라 좀 더 힘들었던 것 같네요.

- 영어 공부
	오늘은 driving factor 라는 숙어에 대해 얘기를 해볼까 합니다.

	Fame is driving force whose want be an actor.
	-> 배우가 되고 싶은 사람은 명성이 원동력입니다.

	Money is the driving force in finding a new job.
	-> 새로운 직장을 찾는 것의 원동력은 돈입니다.

	이렇게 원동력이라는 말을 쓰고 싶은 경우 사용할 수 있습니다.

- 독서 로그
	양자역학 수업을 계속 읽고 있습니다.
	바쁜 탓에 속도가 나지를 않네요.
	오늘은 좀 늦게 자더라도 다 읽고 자야겠습니다.

여러분 2019년에는 같이 성장해보아요!

