---
title: '[Daily LifeLog] 2019/03/02'
date: 2019-03-02 21:46:26
categories: 라이프로그
tags: LifeLog
---

2019년 3월 2일자 라이프로그 입니다.

- 운동

  오늘은 휴일이니까!
  운동은 쉴께요!

- 영어 공부

	오늘의 단어입니다.
  metacognition (명사, noun)
	→ Awareness and understanding of one`s own thought processes.
	: 자신의 생각을 어느정도 이해하고 있는 것인지 알고 있는 것.

  intention (명사, noun)
	→ a thing intended; an aim or plan.
	: 의도된 것; 목표 또는 계획.

	예문입니다.
	I think he is want to work with anyone because he has good metacognition.
	→ 나는 그가 훌륭한 메타인지 능력을 가지고 있기 때문에 누구와도 일하고 싶은 사람이라고 생각합니다.

	This comment doesn`t have intention.
	The method or function name should have intention then that code has more readability and easy to understand.
	→ 이 주석에는 의도가 없습니다.
	메소드나 함수 이름은 가독성이 뛰어나고 이해하기 쉽도록 의도되어야 합니다.

	오늘은 이상한모임의 컨퍼런스 99콘에 다녀왔습니다.
	거기서 말씀해주신 것들중 메타인지와 의도적인 연습에 대한 내용이 나와서 관련해서 영어 단어를 찾아보았습니다.

	아래는 pick, select, choose의 예문입니다.

	He picked a snack that looked better delicious.
	→ 그는 더 맛있게 보이는 스낵을 골랐다.

	I respect his select.
	→ 나는 그의 선택을 존중한다.

	You should choose it because getting lucky for your life.
	→ 당신의 인생에 운이 좋아지기 때문에 그것을 선택해야 합니다.    

	오늘은 어제 못적었던 내용까지 같이 적으려고 하니 양이 많군요!

	그래도 약속은 약속이니 추가로 예문을 더 작성해보았습니다.
	pick, select, choose는 굉장히 많은 의미를 가지고 있다보니 일상생활에서 자주 사용할 수 있는 표현이 많은 것 같네요.

- 독서 로그

	프로그래머를 위한 기초 해석학을 읽는 중입니다.

	조만간 리뷰를 써야 하기에 오늘은 밤을 새서라도 꾸역꾸역 끝까지 읽어야겠네요.
	수학의 기초 개념의 주요 정리 요약을 여기에 적어봅니다.

	정리.1) 유리수의 조밀성
	임의의 다른 두 유리수 a > b에 대해 a > c > b를 만족하는 유리수 c가 무수히 존재합니다.

	정의.1) 데데킨트 절단
	A ∪ B = R, A ∩ B = ø
	a ∈ A, b ∈ B ⇒ a < b
	이때 집합 조합 (A, B)를 실수의 하나의 절단이라고 부릅니다.

	정리.2) 실수의 완비성
	실수의 임의의 절단 (A, B)에 대해 다음 중 하나가 성립합니다.
	A에 최댓값이 존재하면 B에 최솟값이 존재하지 않습니다.
	B에 최솟값이 존재하면 A에 최댓값이 존재하지 않습니다.

	정리.3) 상한 하한의 존재

	정의.2) 가산무한집합

	정리.4) 자연수, 정수, 유리수의 농도

	정리.5) 실수의 농도

	정의.3) 수열의 극한

	정리.6) 실수의 무한소수 전개

	정리.7) 아르키메데스 원리

	정리.8) 두 개의 실수 간에 존재하는 유리수

	내용은 계속 채우도록 하겠습니다.

2019년에는 모두 같이 성장합시다!
