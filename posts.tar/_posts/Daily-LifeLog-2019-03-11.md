---
title: '[Daily LifeLog] 2019/03/11'
date: 2019-03-12 09:37:30
categories: 라이프로그
tags: LifeLog
---

2019년 3월 11일 라이프로그 입니다.

- 운동

  11일에도 20층 계단 오르기 완료 했습니다!

- 영어 공부

  오늘의 단어입니다.

  rarely (부사, ADVERB)
    -> Not often; seldom.
    : 가끔, 드물게

  pros and cons(숙어, PHRASE)
    -> strength and weakness
    : 장점과 단점

  예문입니다.

  -> I rarely drive above 50 mph 
  : 나는 50 mph로 운전한적이 거의 없다.

  -> Here are some more of the pros and cons of technology to think about and discuss.
  : 여기 기술에 대한 몇가지 장점과 단점에 대해 생각하고 논의 해보자.

  이상입니다.

- 독서 로그

  프로그래머를 위한 기초 해석학을 다시 초반부 부터 읽고 있습니다.
  약간 설렁설렁 읽었더니 뒷부분에서 전혀 이해가 가지 않는 초유의 사태가....
  그래서 제대로 이해하면서 다시 읽고 있습니다!

  이건 정리하면서 읽어야 할것 같네요.
  조만간 정리하는 내용을 포스팅 하겠습니다!

  어제는 그냥 뻗어버리는 바람에 지금 이 글은 11일이 아닌 12일에 쓰고 있네요.
  오늘과 내일에 걸쳐서 회사에서 워크샵을 갑니다!
  가능하면 쓰겠지만, 쓰지 못할 확률이 높네요
	쓰지 못하면 워크샵 다녀와서 작성 하도록 하겠습니다!

2019년에는 모두 같이 성장합시다!
